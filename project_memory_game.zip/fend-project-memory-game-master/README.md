Welcome to the Memory Game Project

Gameplay

There are sixteen pieces of the card on the board. the objective is to choose a card one by one and remember the picture on the card. Next you will try to find a match throughout the other 16 cards. If you manage to match a card then the cards will turn teal to show correlation, if you fail then both cards will turn back around and you have to try again.


Star ratings are measured by the amount of red stars that you have. You start off with black stars and you must try to keep as many as possible. The star rating measures are:

past 10 is one red star
past 18 is the second star and a prompt
past 25 is the third star

Once you get all of the pictures matched or you manually reset the game by hitting the reset icon, that instance of the game is over and you can play again!
