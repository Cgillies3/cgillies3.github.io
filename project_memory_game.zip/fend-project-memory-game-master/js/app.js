//list of cards
const pics = ["fa fa-anchor", "fa fa-bolt", "fa fa-bomb", "fa fa-bicycle",
    "fa fa-cube", "fa fa-diamond", "fa fa-leaf", "fa fa-paper-plane-o",
    "fa fa-anchor", "fa fa-bolt", "fa fa-bomb", "fa fa-bicycle",
    "fa fa-cube", "fa fa-diamond", "fa fa-leaf", "fa fa-paper-plane-o",
];

//the playing board
const wholeBoard = document.querySelector("#board");


//For the game timer

let hour = 0;
let minute = 0;
let second = 0;

const gameTimer = document.querySelector('.game-time');

const hourTime = document.querySelector(".hour");
const minuteTime = document.querySelector(".minute");
const secondTime = document.querySelector(".second");

let timeCount;
let timerOn = false;

//BUTTONS
const tryHard = document.querySelector('.decision');
const yesButton = document.querySelector('.yes-button');
const noButton = document.querySelector('.no-button');
//move counter on the top of the screen
let moves = 0;
const movesNumber = document.querySelector(".moves");

// for the rating
const ratingStars = document.querySelector('.stars');
const star = document.querySelector('.stars').childNodes;

//For restarting the game_box
const restartGame = document.querySelector(".restart");


//POP up for after the game_box

const popup = document.querySelector('.game-box');
const timePopup = document.querySelector('.time-pop');
const ratingPopup = document.querySelector('.rating-pop');
const movesPopup = document.querySelector('.moves-pop');
const buttonReset = document.querySelector('.restart-game');
const afterGame = document.querySelector('.after-game');


//ARRAYS
let pickedCards = [];
let matchCards = [];


function shuffle(array) {
    var currentIndex = array.length,
        temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}


//Create the board of cards witha function and add event listener
boardCreate()


function boardCreate() {
    wholeBoard.innerHTML = "";
    const newCards = document.createElement('ul');
    newCards.classList.add('new-deck');

    let shuffleCards = shuffle(pics);
    // CREATE NEW LIST ITEMS AND ADD TO THE LIST
    for (let i = 0; i < shuffleCards.length; i++) {
        const nLi = document.createElement('li');
        nLi.classList.add('new-card');
        nLi.innerHTML = `<i class="${shuffleCards[i]}"></i>`;
        newCards.appendChild(nLi);
    }
    wholeBoard.append(newCards);
    wholeBoard.addEventListener('click', clickResponse);
}

//Event listener and if the cards are matched or not
function clickResponse(evt) {
    let selected = evt.target;
    if (selected.classList.contains("new-card") &&
        !selected.classList.contains("open")) {
        // to start the timer once
        if (timerOn === false) {
            timerOn = true;
            beginTime();

        }
        selected.classList.add('open');
        pickedCards.push(selected);
    }
    if (pickedCards.length === 2) {
        wholeBoard.classList.add('no-choice');

        numMoves();
        // if the cards are matched call the matched function
        if (pickedCards[0].innerHTML === pickedCards[1].innerHTML) {
            same();
        } else {
            setTimeout(notSame, 500);
        }
        done();
    }
}


//if two cards are the same
function same() {
    // add class match to both cards
    pickedCards[0].classList.add("new-match");
    pickedCards[1].classList.add("new-match");

    // remove open color to the matches
    pickedCards[0].classList.remove("open");
    pickedCards[1].classList.remove("open");

    matchCards.push(pickedCards[0]);
    matchCards.push(pickedCards[1]);
    pickedCards = [];
    // cards can be chosen again
    wholeBoard.classList.remove('no-choice');

}
//if two cards are not the startTimer

function notSame() {

    pickedCards[0].classList.remove("open");
    pickedCards[1].classList.remove("open");
    // remove cards from checkCards array
    pickedCards = [];
    // to allow opening and checking two cards again
    wholeBoard.classList.remove("no-choice");

}


//This will help the time reset
function timeSolve(x, y) {
    if (x < 10) {
        return (y.innerHTML = '0'+ x );
    } else {
        return (y.innerHTML = x);
    }
}

// This function will increment the move counter
function numMoves() {

    moves++;
    if (moves === 1) {
        movesNumber.innerHTML = '1 move';
    } else {
        movesNumber.innerHTML = moves + ' ' + 'Moves';
    }
    scoreRate();
}

// function that sets star rating accordingly to how well player is doing
function scoreRate() {

    if (moves === 10) {

        star[5].classList.add('red');

    } else if (moves === 18) {

        star[3].classList.add('red');
        tryHard.style.display = 'block';
        noButton.addEventListener('click', function() {
            tryHard.style.display = 'none';
            gameOver();

        })

        yesButton.addEventListener('click', function() {
            tryHard.style.display = 'none';

        })

    } else if (moves === 25) {

        star[1].classList.add('red')
    }
}


function beginTime() {
    if (second === 0) {
        second++;
    }

    timeCount = setInterval(function() {

        hourTime.innerHTML = `${hour}`;
        minuteTime.innerHTML = ` ${minute} `;
        secondTime.innerHTML = ` ${second} `;
        // adjusts the timer accordingly
        timeSolve(second, secondTime);
        timeSolve(minute, minuteTime);
        timeSolve(hour, hourTime);

        second++;
        if (second === 60) {
            minute++;
            second = 0;
        } else if (minute == 60) {
            hour++;
            minute = 0;
        }
    }, 1000);
}


//when the game is over these are the next steps

function done() {

    if (matchCards.length === 16) {
        //adds the correct numbers to the end game popup
        timePopup.innerHTML = gameTimer.innerHTML;
        ratingPopup.innerHTML = ratingStars.innerHTML;
        movesPopup.innerHTML = movesNumber.innerHTML.slice(0, 3);

        //stops the time and brings up the extra end game screen
        clearInterval(timeCount);
        afterGame.style.display = 'block';
    }
}

buttonReset.addEventListener('click', function() {

    afterGame.style.display = 'none';
    gameOver();
})

// RESTARTING THE GAME
function gameOver() {

    moves = 0;
    movesNumber.innerHTML = `0 Moves`;
    // empty both arrays
    matchCards = [];
    pickedCards = [];
    // to clear the old board, create a new
    boardCreate();
    // This  will stop the times
    clearInterval(timeCount);
    timerOn = false;
    second = 0;
    minute = 0;
    hour = 0;
    secondTime.innerHTML = '00';
    minuteTime.innerHTML = '00';
    hourTime.innerHTML = '00';
    // reset the color of the stars
    star[5].classList.remove('red');
    star[3].classList.remove('red');
    star[1].classList.remove('red');
}


// to restart  the game when the player click on the restart icon
restartGame.addEventListener("click", gameOver);
