
let shape = document.getElementById('pixelCanvas');
let picker = document.getElementById('sizePicker');
let inputProp = document.querySelectorAll('input');

//MAIN FUNCTION FOR BUILDING THE GRID
function makeGrid() {
  let w = inputProp[1].value;
  let h = inputProp[0].value;
  let square = '';
//LOOP AND CREATE CELLS
  for (let i = 0; i < h; i++) {
        square += '<tr class="row-' + i + '">';
        for (let j = 0; j < w; j++) {
            square += '<td class="cell" id="row-' + i + '_cell-' + j + '"></td>';
        }
        square += '</tr>';
}
    shape.innerHTML = square;
    addColor();
}
// THIS IS THE LISTENER FOR THE SUBMIT BUTTON
inputProp[2].addEventListener('click',function(evt){
  evt.preventDefault();
  makeGrid();
});
// TO ADD COLOR
function addColor(){

  const insideSquare = document.getElementsByClassName('cell');
  for (let k = 0; k < insideSquare.length; k++) {
        insideSquare[k].addEventListener('click', function (event) {
            event.target.style.backgroundColor = colorPicker.value;

})
}
}
